package com.example.lojaunitpe.repositorios;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.lojaunitpe.modelos.Funcionario;

public interface FucionarioRepositorio extends JpaRepository< Funcionario,Long>	{

}

package com.example.lojaunitpe.repositorios;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.lojaunitpe.modelos.Estado;

public interface EstadoRepositorio extends JpaRepository<Estado,Long>	{

}

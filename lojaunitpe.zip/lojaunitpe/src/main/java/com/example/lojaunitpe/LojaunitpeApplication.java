package com.example.lojaunitpe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LojaunitpeApplication {

	public static void main(String[] args) {
		SpringApplication.run(LojaunitpeApplication.class, args);
	}

}

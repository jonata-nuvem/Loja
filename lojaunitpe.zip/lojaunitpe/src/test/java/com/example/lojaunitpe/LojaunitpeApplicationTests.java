package com.example.lojaunitpe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LojaunitpeApplicationTests {

	@Test
	void contextLoads() {
	}

}
